#Dash and related modules
import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
#plotly graph objects to create the plot itself
import plotly.graph_objs as go
import numpy as np
from scipy.integrate import odeint



import plotly.graph_objects as go # or plotly.express as px
fig = go.Figure()

app= dash.Dash()
#Our dash will be very simple, just the graph
app.layout = html.Div([dcc.Graph(id='graph'),
                       #and four sliders for the paramaters
                     html.Div([html.Div(children='Beta'),dcc.Slider(id='beta',
                                     min=0,max=1,step=.05,marks = {0:'0',0.5:'0.5',1:'1'},
                                     value=.2)]),
                      html.Div([html.Div(children='Gamma'),dcc.Slider(id='gamma',
                                     min=0,max=1,step=.05,marks = {0:'0',0.5:'0.5',1:'1'},
                                     value=.1)])])
                      

#Telling Dash that the sliders are inputs into the graph
@app.callback(Output('graph','figure'),
             [Input('beta','value'),
             Input('gamma','value')])
#And this function takes the inputs, runs the model and plots the output

def update_figure(beta,gamma):
   
    N = 2000
    
    S = N-1
    I = 1
    R = 0

    def modelo_SIR(y,t,N,beta,gamma):
        S, I, R = y
        dS_dt = - (beta*S*I)/N
        dI_dt = (beta*I*S)/N - (gamma*I)
        dR_dt = (gamma*I)
        return dS_dt, dI_dt, dR_dt

    y0 = S,I,R
    t= np.linspace(0,365,365)

    Sol_Sir_odeint = odeint(modelo_SIR, y0,t, args=(N, beta, gamma))
    S, I, R = Sol_Sir_odeint.T
    
    data = [go.Scatter(x=list(range(0,365)), y=S, mode='lines', name='S'),
            go.Scatter(x=list(range(0,365)), y=I, mode='lines', name='I'),
            go.Scatter(x=list(range(0,365)), y=R, mode='lines', name='R')]
    
    
    layout = go.Layout(title = f'modelo SIR')
    return {'data':data,'layout':layout}



app.run_server(debug=False)

