import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# parâmetros
a = 0.7; b = 0.5; c = 0.3;  e = 0.2

#função da equação diferencial

def dP_dt(P, t):
    return [P[0]*(a - b*P[1]), -P[1]*(c - e*P[0])]

# vetor tempo

t = np.linspace(0, 100, 10000)

# condição inicial

P0 = [1.0, 0.5]

#aplicação do odeint

Ps = odeint(dP_dt, P0, t)

# separação das variáveis

prey = Ps[:,0]
predators = Ps[:,1]

#plot


#plt.style.use('classic')
plt.plot(t, prey,  label="Rabbits", linewidth = 2)
plt.plot(t, predators,  label="Foxes", linewidth = 2)
plt.xlabel("Time")
plt.ylabel("Population")
plt.legend();
plt.show()