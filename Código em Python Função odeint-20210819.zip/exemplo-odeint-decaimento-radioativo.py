import numpy as np
from scipy.integrate import odeint
from math import log
#import math
import matplotlib.pyplot as plt

# Define a function which calculates the derivative
def dN_dt(N, t):
    TempoMeiaVida=30.0
    k=log(2)/TempoMeiaVida
    return -k*N

t = np.linspace(0,100,101)
N0 = 1.0  # the initial condition
N = odeint(dN_dt, N0, t)
#N = np.array(N).flatten()



# Plot the numerical solution
plt.rcParams.update({'font.size': 14})  # increase the font size
plt.xlabel("t")
plt.ylabel("N(t)")
plt.title("Decaimento Radioativo")
plt.plot(t, N)
plt.show()

