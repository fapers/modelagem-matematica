import numpy as np

x=np.array([1,2,3,4])

print(x)

def FuncaoAoQuadrado(x):
    w=x*x
    return w


y=FuncaoAoQuadrado(x)

print(y)