import random

for i in range(10):

    a = random . random ()

    print(a)
    
