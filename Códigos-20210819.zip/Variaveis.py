
a = 1

#print(a)

#print(type(a))

b = 1.1

#print(b)

#print(type(b))

c = "Fabiano"

#print(c)

#print(type(c))

d = str(a)

#print (d)

#print (type(d))

d = int(d)

e = d +1

#print(e)

lista = [a,b,c]

print(lista)

#print(type(lista[0]))

lista.append("2021") # oomando append serve para adicionarmos termos à lista

print(lista)

                 
                 
                 