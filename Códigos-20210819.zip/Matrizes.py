

mat = []

linhas = 2
colunas = 3 

for i in range ( linhas ):
    
    
   lin = []
    
   for j in range (colunas):
           
       a = "a"+str(i+1) + str(j+1)
        
       #print(a)
        
       lin.append(a)
       
   #print(lin)
   mat.append(lin)
   
print(mat)

print(mat[0][1])