from matplotlib import pyplot as plt

x = []
y = []

for i in range(1,100):
    #print(i)
    x.append(i)
    y.append(i ** 2)

print(x)
print(y)

plt.plot(x,y)

plt.title('Gráfico 1')
plt.xlabel('x')
plt.ylabel('y')


plt.show()
