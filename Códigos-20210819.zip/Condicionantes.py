
a = 6

if( a >= 6):
    print("a > 6")
else:
    print("a < 6")